list(
  rd_family_title = list(
    angles = "",
    assay = "v3 Assay object, validity, and interaction methods:",
    assay5 = "v5 Assay object, validity, and interaction methods:",
    command = "Command log object and interaction methods",
    dimnames = "",
    dimreduc = "Dimensional reduction object, validity, and interaction methods",
    fov = "",
    key = "",
    logmap = "Logical map objects, validity, and interaction methods:",
    s4list = "",
    segmentation = "Segmentation layer classes:",
    seurat = "Seurat object, validity, and interaction methods",
    sparse = "",
    stdassay = "v5 Standard Assay object, validity, and interaction methods",
    subobjects = ""
  )
)
