#' @inherit <%= fxn %> params return title description details sections
#' references author source
#' @name <%= fxn %>-StdAssay
#' @rdname <%= fxn %>-StdAssay
#'
#' @keywords internal
#'
#' @export
