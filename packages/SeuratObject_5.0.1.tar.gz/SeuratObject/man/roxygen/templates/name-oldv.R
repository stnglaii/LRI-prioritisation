#' @name <%= fname %>-v<%= as.integer(version) %>
#' @rdname <%= fname %>-v<%= as.integer(version) %>
#'
#' @note This is the documentation for \code{<%= fname %>} for
#' v<%= as.integer(version) %>; for the latest documentation, please see
#' \code{\link{<%= fname %>}}
#'
#' @seealso \code{\link{<%= fname %>}}
