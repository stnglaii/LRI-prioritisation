#' @section Lifecycle:
#'
#' \Sexpr[stage=build,results=rd]{lifecycle::badge("superseded")}
