#' @description Validation of \code{<%= cls %>} objects is handled by
#' \code{\link[methods]{validObject}}
