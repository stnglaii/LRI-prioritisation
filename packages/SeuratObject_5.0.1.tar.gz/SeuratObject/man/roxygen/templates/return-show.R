#' @return Prints summary to \code{\link[base]{stdout}} and invisibly
#' returns \code{NULL}
