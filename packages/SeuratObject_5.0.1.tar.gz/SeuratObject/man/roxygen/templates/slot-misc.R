#' @slot misc A named list of unstructured miscellaneous data
