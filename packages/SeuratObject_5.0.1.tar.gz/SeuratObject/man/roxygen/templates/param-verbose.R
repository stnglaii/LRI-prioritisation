#' @param verbose Show progress updates
