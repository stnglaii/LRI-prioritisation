#' @section Lifecycle:
#'
#' \Sexpr[stage=build,results=rd]{lifecycle::badge("experimental")}
#'
#' \strong{Warning}: functionality described here is experimental and prone to
#' change without notice
