/* For backwards compatibility only.  Packages should start using */
/* LinkingTo: Matrix (>= 1.6-2) and #include <Matrix/cholmod.h>.  */
#include "Matrix/cholmod.h"
