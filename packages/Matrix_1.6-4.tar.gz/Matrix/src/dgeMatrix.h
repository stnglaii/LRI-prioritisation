#ifndef MATRIX_DGEMATRIX_H
#define MATRIX_DGEMATRIX_H

#include <Rinternals.h>

SEXP dgeMatrix_Schur(SEXP, SEXP, SEXP);
SEXP dgeMatrix_exp(SEXP);

#endif /* MATRIX_DGEMATRIX_H */
