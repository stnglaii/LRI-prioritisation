#ifndef MATRIX_MINLINES_H
#define MATRIX_MINLINES_H

/* Currently none ... */

#endif /* MATRIX_MINLINES_H */
