#ifndef MATRIX_BIND_H
#define MATRIX_BIND_H

#include <Rinternals.h>

SEXP R_bind(SEXP);

#endif /* MATRIX_BIND_H */
